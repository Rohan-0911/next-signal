"""Run the agent on many companies and write out/eval.csv.  Usage: python scripts/batch.py"""
import csv, json, pathlib, subprocess, sys, time

COMPANIES = [
    "HINDUNILVR", "ITC", "NESTLEIND", "BRITANNIA", "DABUR", "TATACONSUM",
    "MARICO", "GODREJCP", "COLPAL", "TITAN", "TRENT", "ASIANPAINT",
]
OUT = pathlib.Path("out")
rows = []
for sym in COMPANIES:
    print(f"=== {sym} ===", flush=True)
    t0 = time.time()
    p = subprocess.run([sys.executable, "run.py", sym], capture_output=True, text=True)
    tail = (p.stdout or "").strip().splitlines()[-3:]
    saved = sorted(OUT.glob(f"{sym}_*.json"), key=lambda f: f.stat().st_mtime)
    row = {"company": sym, "seconds": round(time.time() - t0), "log": " | ".join(tail)[:200]}
    if saved:
        d = json.loads(saved[-1].read_text(encoding="utf-8"))
        row.update(strength=d["strength"], discovery=d["discovery"][:160],
                   evidence_items=len(d.get("evidence", [])), file=saved[-1].name)
    rows.append(row)
    time.sleep(30)
keys = ["company", "strength", "discovery", "evidence_items", "seconds", "file", "log"]
with open(OUT / "eval.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
print("wrote out/eval.csv")